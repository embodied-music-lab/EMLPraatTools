# Brief — complete handoff to Opus, 28 August 2026

Fable. This zip is self-contained; assume nothing else was passed along.
Where any document here conflicts with an older one in your tree, this
zip governs, and within it the two files in this list marked CURRENT
govern the rest.

## Contents

- `00_BRIEF.md` — this file.
- `orders/WORK_ORDER_UNIFICATION_2026-08-28.md` — CURRENT. The build.
- `orders/RULINGS_SOL_ITEMS_2026-08-28.md` — CURRENT. Dispositions on
  Sol's nine items, measured repo state, and the standing work lists.
- `orders/cda1a783-MEMO_TO_FABLE_TIERS_20260828.md` — your tiers memo,
  approved; superseded only where the unification order tightens it.
- `orders/` (item 22, presentation, consolidated memos) — the 27 Aug
  orders, already largely built; kept for reference and for my
  inspection trail.
- `examples/` — the approved worked examples: README v8, coverage v5,
  SUMMARY, exceptions, agreement_by_procedure, agreements_all,
  disagreements_all. Templates for the generated versions. Note:
  disagreements_all's reason column is the known register defect; the
  reader-sentence mapping fixes it (already ruled).
- `sol/SOL_HANDOFF_AND_CLARIFICATION.md` — Sol's material, verbatim
  substance. Sol's counts are DESIGN INTENT, not measurement.
- `paper/PAPER_DRAFT_SOL_MOCKUP.md` — the manuscript mock-up. Every
  number in it is unestablished until the unification layer reproduces
  it from a run at a pushed commit.

## State of the world, measured at origin/main 6305327b

Built: the green 624-case kit (certified 27 Aug at 98729af), the
presentation layer through the reader-sentences and wordlist commits.
Not built: tier/study integration (no tier column, no sweep or NIST
cells in matrix.tsv), grand_ledger.tsv, refusal-set equality, the
MAXROW fix, the two-way direct kernel, the registry, the plot.

Two items from me: (1) the kit README was revised after my v8
("clarity and inclusivity") — send me the diff; wording is mine to
approve per the standing rule. (2) The 11-declared-vs-20-actual refusal
gap was visible in the verdict I inspected and I missed it; Sol's item
3 is confirmed and lands first.

## Execution order

1. Refusal-set equality + the nine stale expectations.
2. `emlResult_MAXROW` fix + regression test.
3. Unification layer → `grand_ledger.tsv` (the work order).
4. Tier B count verdict: reproduce 626 or correct the paper.
5. NIST criterion per Sol item 4.
6. Two-way direct kernel — AFTER the Type II/III measurement comes to
   me (measure what run_analyses.R actually passes to car::Anova and
   what Praat's report used; I declare the convention).
7. Registry, then the plot, from the ledger.
8. Fresh three-study run on Ian's machine at a pushed commit; my
   inspection; then the frozen-release candidate.

## Standing outside the kit (unchanged)

Door-round punch list (wizard build gated on Ian's items 1–21 batch
approval — still pending), survey module Stages 3–6, CI Lane 10 (v47
crash; required before the frozen release the paper cites), About menu
item, behavioral-constant census, error-sweep completion before any
1.0 tag.
