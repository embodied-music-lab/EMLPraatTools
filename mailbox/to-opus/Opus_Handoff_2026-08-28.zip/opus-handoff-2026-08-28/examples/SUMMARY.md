# Validation summary — EML Stats & Graphs against R

Run 27 August 2026, plugin commit `98729af`, on macOS with current Praat
and R 4.3.3. Verdict: **green — every quantity accounted for.**

## What was compared

The kit ran 624 analyses through 17 of the plugin's statistical procedures
— descriptives, normality, two-group and paired comparisons, one-way,
two-way and repeated-measures ANOVA with their post-hocs, Kruskal-Wallis,
Friedman, correlation, regression, chi-square, and the reliability family
— and ran the same 624 analyses in R using the standard functions
(`t.test`, `wilcox.test`, `aov`, `cor.test`, `shapiro.test`, and
colleagues). It then compared 10,841 numerical results pairwise.

**10,792 of 10,841 agree to at least nine significant digits** (values at
machine zero are compared absolutely, below 1e-12). The remaining 49 are
listed in full in `exceptions.tsv`, one row each, with the reason beside
the numbers. There are no unexplained differences: an accounting identity
inside the comparison proves every quantity from both programs landed in
exactly one category, and the run fails loudly if one ever doesn't.

## The 49 exceptions, in plain terms

**Two-way ANOVA (18).** The plugin reads Praat's own printed ANOVA table,
which carries about nine significant digits, so its two-way results
inherit that ceiling. Worst case: 1.3 parts per hundred million.

**Tukey's adjusted p-values (14).** The q statistics match R exactly, to
the last bit. The p-values derived from them differ only for p below
0.00001, because the two programs numerically evaluate the studentized-
range distribution differently in the far tail — worst case 0.13% at
p ≈ 5e-12. No difference at any usable significance level.

**Reliability on a degenerate sample (2).** Leave-one-out alpha on a
3-person sample computes alpha on the 2 who remain. The plugin matches
the textbook formula there (verified by hand: −8/3 exactly); the psych
package returns −3.0. This is one of two places where the deviation
belongs to the R side.

**Refusal wording (15 text rows).** Where data can't be analyzed, both
programs refuse the same 24 analyses — verified case by case. Each writes
its refusal message in its own words.

## Quantities only one side reports

R reports many intermediate quantities the plugin doesn't print, and two
kinds deserve a sentence. The plugin prints pairwise confidence intervals
only under corrections that mathematically define them (Tukey, Scheffé,
Bonferroni), so on Holm and Benjamini-Hochberg rows the interval exists
on the R side alone — by design, and the reports say so. And R's
`wilcox.test` reports a shift estimate from an internal shortcut that
differs from the textbook Hodges-Lehmann definition by about 4 parts in
100,000; the plugin computes the definition, the two are compared where
they can be, and R's shortcut value is recorded rather than imitated —
the second place the deviation is R's.

## Run it yourself

1. Open `RUN_ME_FIRST.praat` in Praat and run it.
2. Source `run_analyses.R` in R.
3. Source `compare.R`. It prints this verdict and rewrites this folder.

The full row-by-row working record, including the two raw result tables
and every per-analysis report from both programs, is in `audit/`.
