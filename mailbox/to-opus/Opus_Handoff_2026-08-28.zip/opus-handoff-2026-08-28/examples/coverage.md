# What the kit tests, procedure by procedure

One row per plugin procedure: the Praat procedure name, the R functions
the kit compares it against, the options the 624 analyses exercise, and
how many analyses cover it. Option lists come from `matrix.tsv`; the R
functions are the calls in the matching section of `run_analyses.R`.

| Procedure | Praat procedure | Compared against (R functions) | Options exercised | Analyses |
|---|---|---|---|---|
| Descriptive statistics | `@emlRunDescriptiveAnalysis` | `psych::describe`, `stats::t.test` (CI of the mean), `stats::lm` (trend line) | — | 41 |
| Normality assessment | `@emlRunNormalityAnalysis` | `stats::shapiro.test`, `psych::describe` (skewness, kurtosis) | — | 41 |
| Two-group comparison | `@emlRunTwoGroupAnalysis` | `stats::t.test`, `stats::wilcox.test`, `effectsize::cohens_d`, `rstatix::cohens_d`, `effectsize::hedges_g`, `rstatix::wilcox_effsize` | parametric / nonparametric / both; equal variances on and off; both group orders | 34 |
| Paired comparison | `@emlRunPairedAnalysis` | `stats::t.test(paired)`, `stats::wilcox.test(paired)`, `effectsize::cohens_d`, `rstatix::cohens_d`, `rstatix::wilcox_effsize` | parametric / nonparametric / both | 25 |
| One-way ANOVA | `@emlRunAnovaAnalysis` | `stats::aov`, `stats::TukeyHSD`, `effectsize::eta_squared`, `rstatix::eta_squared`, `effectsize::cohens_d`, `rstatix::cohens_d` | with and without Tukey; both group orders | 40 |
| Kruskal-Wallis | `@emlRunKWAnalysis` | `stats::kruskal.test`, `rstatix::dunn_test`, `rstatix::kruskal_effsize`, `effectsize::rank_eta_squared`, `effectsize::rank_epsilon_squared`, `rstatix::wilcox_effsize` | with and without Dunn; Holm, Bonferroni, BH; both group orders | 80 |
| Pairwise comparisons | `@emlRunPairwiseAnalysis` | `stats::t.test` per pair, `stats::wilcox.test` per pair, `effectsize::cohens_d` | Welch, Student, Wilcoxon, Scheffé; Holm, Bonferroni, BH, none; both group orders | 200 |
| Repeated-measures ANOVA | `@emlRunRepeatedMeasuresAnalysis` | `afex::aov_ez`, `effectsize::eta_squared`, `stats::t.test(paired)` per pair | with and without post-hoc; Holm, Bonferroni, BH | 22 |
| Friedman test | `@emlRunFriedmanAnalysis` | `stats::friedman.test`, `rstatix::friedman_effsize`, `stats::wilcox.test(paired)` per pair | with and without post-hoc; Holm, Bonferroni, BH | 22 |
| Two-way ANOVA | `@emlRunTwoWayAnalysis` | `stats::lm` + `car::Anova` (Type III), `effectsize::eta_squared` | — | 3 |
| Correlation | `@emlRunCorrelationAnalysis` | `stats::cor.test` (Pearson, Spearman) | Pearson / Spearman / both | 35 |
| Regression | `@emlRunRegressionAnalysis` | `stats::lm` | — | 10 |
| Grouped regression | `@emlRunGroupedRegression` | `stats::lm` overall and per group | both group orders | 6 |
| Chi-square independence | `@emlChiSquareIndependence` | `stats::chisq.test`, `effectsize::cramers_v`, `rstatix::cramer_v` | with and without continuity correction | 8 |
| Wilson interval | `@emlWilsonInterval` | `stats::prop.test` | confidence level 0.90 / 0.95 / 0.99 | 27 |
| Cronbach's alpha | `@emlCronbachAlpha` | `psych::alpha`, `psych::alpha.ci` (Feldt CI) | confidence level 0.90 / 0.95 / 0.99 | 22 |
| Alpha respondent influence | `@emlAlphaInfluence` | leave-one-out over `psych::alpha` | — | 8 |

Totals: 17 procedures, 624 analyses. Each analysis contributes every
quantity both programs report; the comparison covers 10,841 quantities in
the current run.
