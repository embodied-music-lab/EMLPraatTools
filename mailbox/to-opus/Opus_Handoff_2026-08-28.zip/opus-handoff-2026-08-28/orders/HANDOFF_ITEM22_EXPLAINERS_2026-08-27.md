# Handoff to Opus — item 22 resolved, and the explainer ruling

Fable, 27 August 2026, with Ian.

## Item 22 — RESOLVED. Ian approves the strings; light the plumbing.

The approved set, verbatim and complete:

Row label: `p method`, printed under the p line, disclosure class (always
prints, independent of the explainer toggle). Values:

```
exact
t approximation (ties present)         [Spearman]
t approximation (large sample)         [Spearman]
normal approximation (ties present)    [Mann-Whitney, signed-rank]
normal approximation (large sample)    [Mann-Whitney, signed-rank]
t distribution                         [Pearson, every correlation report]
```

Conventions footer addition:
`exact rank p-values: AS 89 for Spearman; exact enumeration for rank-sum and signed-rank`

Everything else stands as already ruled: three insertion sites in
`eml-annotation-procedures.praat`, no kernel or output-helper change, the
method extracted and compared as a kit quantity with the label mapping and
the boundary twins asserting labels, the one-line dispatch fix on the dead
`@emlBridgeCorrelation`, and the door-census widening to every shipped file
that calls a stat kernel. Affected baselines join the standing batched
re-drive.

## Explainer text — finding and ruling (new to you)

Ian noticed explainer annotations in the kit's captured reports. Verified
against the bare-run capture: 96 of 135 reports carry explanation-class
lines ("Why:" lines, value glosses, teaching sentences). Diagnosis,
verified in source: the lane 6 routing landed — those lines all follow
`emlShowExplanations` — but `emlShowExplanationsDefault` is still `1` in
`eml-output.praat`, and the kit drives the scripting interface where no
dialog runs, so nothing ever lowers the flag.

**New ruling closing the unruled corner: the scripting-interface default is
OFF.** The original ruling covered menu (default off), wizard (always on),
and graphs (inherit by launch path) but never named the scripting path. The
raw report is the canonical product; annotations are opt-in on every path
except the wizard, which forces them on. This is also what the Josh
deliverable requires — clean reports with no harness tricks.

Actions:

1. Flip `emlShowExplanationsDefault` to 0 — the lane 6 defect already
   authorized, evidently not yet landed at the bare-run commit. Confirm the
   dialog-toggle wiring status at your head while you're there.
2. Re-capture the kit report baselines in the standing batch. The extracted
   quantities are untouched — this changes report text only.
3. New acceptance leg: a default kit drive produces reports containing zero
   explanation-class lines, machine-checked by the canonical classifier.
   Red demo: one drive with the flag raised, showing the lines return.

— Fable
