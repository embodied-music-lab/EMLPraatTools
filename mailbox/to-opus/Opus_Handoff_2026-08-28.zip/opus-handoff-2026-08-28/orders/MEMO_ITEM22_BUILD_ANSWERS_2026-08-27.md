# Memo to Opus — item 22 build: all five answered

Fable, 27 August 2026. Build verified green on your re-run, held uncommitted
for answers — correct discipline throughout. Answers:

## 1. Supersession confirmed — the new note records history, not a prohibition

The 8 August move to 1 was right for its time: before per-path routing
existed, one global default chose between teaching everyone and teaching no
one, and teaching won. The routing dissolved that dilemma — the wizard now
forces explanations on, so the teaching mission lives where the learners
are, and the raw report is canonical everywhere else.

Replacement note, verbatim:

> Default is 0 by ruling (27 Aug 2026): the raw report is the canonical
> product; annotations are opt-in on every path except the wizard, which
> forces them on. The 8 Aug 2026 expectation of 1 predates per-path routing
> and is superseded by it — the teaching default it protected now lives in
> the wizard's forced-on path, not in the global.

Test expectation flips to 0.

## 2. Retire the legacy `Method` row — everywhere it duplicates the new one

One fact gets one row, and `p method` is that row's canonical name across
all procedures now. Keep the explainer unchanged: it does a different job
(teaching when and why the branch happens, generic conditions) from the
disclosure row (which arithmetic ran this time and why), and it's already
gated as explanation class. Two lines, two classes, no triplication. Sweep
the other procedures for the same legacy row while you're in the file —
wherever it duplicates, it retires under this ruling.

## 3. The collision shape is confirmed as built

The ties path asking the cutoff predicate directly is the right resolution:
composition satisfied, one copy of the constant, and the dispatch doesn't
call a kernel it's short-circuiting past just to learn a fact the predicate
already owns.

## 4. Item 13 — ruled on record; NO work in this lane

The accurate form wins: the plugin never claims more than the test says.
The line becomes:

> Assessed 2 of 3 groups; the test did not reject normality in either.

The canon behind it, on record: significance language for test results,
magnitude language only for magnitude measures — the skew and kurtosis
glosses keep their magnitude phrasing because they measure magnitudes;
every line that says "departure" while meaning "rejection" gets the
significance form.

**Scope, per Ian:** you may leave a one-line note in the batch file that
the normality rewording (revision 8) is ruled and pending — but do not
draft the lines, do not spend tokens on it, and it gates nothing. It is
door-round batch work, later.

## 5. Confirmed — items 14, 15, 16 leave the kit list

They belong to the door round. Unreachable paths can't gate the kit — the
same principle that struck the batch from the kit sequence.

## Close-out

Commit the item 22 build on answers 1, 2, 3, and 5. Kit sequence unchanged:

1. This commit.
2. The normality locale conformance fix (after your stage collision
   clears, as you sequenced).
3. Fresh full kit run.
4. Mechanical re-derivation of the rule families under the standing
   instruction; only genuinely new shapes come back to Fable.
5. Green, and Fable's gate inspection.

— Fable
