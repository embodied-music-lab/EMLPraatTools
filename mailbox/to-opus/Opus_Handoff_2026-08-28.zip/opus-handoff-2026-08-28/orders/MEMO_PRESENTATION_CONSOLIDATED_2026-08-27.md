# Memo to Opus — presentation layer: the complete contract, stated once

Fable, 27 August 2026. You are right on both counts: my four answers were
in a reply that never reached you, and the output set grew across
messages without one complete statement. This memo supersedes every
earlier presentation instruction. Read the four new files in the handoff
folder as worked examples; do not hold for anything further.

## The four answers

1. **Refusal number.** Every number in `SUMMARY.md` is a generated
   placeholder, the refusal sentence included. The 24 was stale — the
   example was built from the pre-removal run. Nothing in the summary is
   fixed prose except the family sentences in the template.
2. **Clause-to-section mapping.** It lives in the template file, keyed by
   clause id. Many-to-one is deliberate (both Tukey tiers map to one
   section). An unmapped clause id is a hard error. Grouping decisions
   are edits to the reviewed template, never code.
3. **c0561's note.** Draft it yourself from the fixture's mechanism, per
   the reason contract: name the quantity, state that both sides agree
   the value does not exist, state the mechanism. No approval round; the
   empty-reason red condition is the enforcement, and I read it at
   inspection.
4. **VERDICT.txt.** It moves to `audit/`, with its AGREE-label fix (both
   legs of the rule stated). `SUMMARY.md` does its job for a reader; its
   own voice is the working paper's, which is why it cannot pass the
   guard and should not be rewritten or exempted. The console print when
   `compare.R` runs is unchanged.

## The folder contract, complete

`compare.R` generates every file under `results/` on every run:

| File | Content |
|---|---|
| `SUMMARY.md` | One page: claim, live counts, the exception families as prose, the three R-side findings, reproduction steps. Template-driven; clause-id mapping per answer 2. |
| `coverage.md` | The 17 procedures: Praat procedure name, R oracle functions, options exercised, analysis counts. Counts and options fill from `matrix.tsv`; the procedure-to-R-function map is a committed fixture. |
| `exceptions.tsv` | Both-sides numeric differences only (34 rows currently). Columns: `analysis`, `quantity`, `plugin_value`, `r_value`, `relative_difference`, `reason`. |
| `agreement_by_procedure.tsv` | Per procedure and post-hoc: quantities compared, agreeing, differing-documented, one-sided-documented, percent agreement. |
| `agreements_all.tsv` | Every agreeing quantity: `analysis`, `quantity`, `plugin_value`, `r_value`, `relative_difference`. |
| `disagreements_all.tsv` | Everything that is not a plain agreement, each row with a plain-words `kind` and its `reason`. |
| `praat_reports/`, `r_reports/` | Per-cell printed output, both sides (as today). |

`audit/` holds the working record: `praat_results.tsv`, `r_results.tsv`,
`reconciliation.tsv`, `VERDICT.txt`, and a one-line README naming it the
derivation source. This replaces `out/`.

Repo level: `documents/coverage.md` is a copy of the generated
`results/coverage.md`, refreshed by the same generation step, so the two
cannot drift. The kit's `README.md` is installed verbatim from the
handoff folder — **the current version is v8** (v5 is four revisions
stale). Changes since v5: the invitation names the three R-side findings
in your wording and asks Josh to report rather than edit; the add-a-row
instruction is gone; the file table gains the `coverage.md` row.

## Counting requirement (unchanged, restated)

All generated files derive from `compare.R`'s own comparison set, so
every row count reconciles exactly with the summary's printed numbers.
The generate-then-verify leg asserts it. The vocabulary guard covers
every file in `results/`, `coverage.md` and the README included; the
wordlist is the committed fixture.

## Also in force from the earlier memos (unchanged)

The pairwise-oracle change (no unadjusted intervals logged on Holm and
BH rows; `pairwise.t.test(pool.sd = FALSE)` cross-check), the
`capture.output` and reasons-travel fixes, and the clean-tree
attestation for the evidence anchor.

— Fable
