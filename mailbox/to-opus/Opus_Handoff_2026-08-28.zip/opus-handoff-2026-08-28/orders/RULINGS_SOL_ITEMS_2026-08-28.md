# Rulings — Sol's nine items, repo state, standing lists

Fable, 28 Aug 2026, measured at origin/main 6305327b.

Repo state: presentation layer built through reader-sentences and
wordlist commits plus two README revisions. Not built: tier column,
sweep/NIST cells, grand_ledger. The paper's run (667 cases, R 4.5.2,
29 Aug) is not reproducible from this repository; treat its numbers as
targets to verify.

Dispositions:
1. grand_ledger — ADOPT, as the evolution of reconciliation.tsv into
   the single generation source, not a parallel artifact. case_id
   exposed in outputs; cell_id stays internal. "Refusal" is already the
   house word.
2. Three named studies — ADOPT. Sol's totals are targets, never
   inputs; independent-total law applies per study and overall.
3. Exact refusal-set equality — ADOPT, first in sequence. Confirmed
   real: the certified verdict showed 11 declared vs 20 actual and my
   inspection passed it unflagged. Update the nine stale expectations;
   require set equality; fail on missing or extra; matched refusals are
   evidence, not failures.
4. NIST LRE criterion — ADOPT as specified (22 df exact; 76 by correct
   digits; within one digit of base R; 10 residual-SD assertions; 98
   total; both sides compared to certified values; complete output
   archived; never forced into the common plot or the general
   threshold).
5. MAXROW — ADOPT. emlResult_MAXROW 4,000 aborting SmLs03/06/09 at
   18,009 rows is a plugin defect. Fix, public route completes for all
   datasets, regression test.
6. ANOVA — ADOPT with one gate. One-way: confirm the direct kernel
   serves the whole public route. Two-way: direct implementation
   replaces the Report-parser; the documented-ceiling ruling is
   superseded (it was always roadmapped). GATE: the SS convention.
   Sol claims the R oracle is car::Anova type = 2; earlier evidence
   recorded Praat's hidden report as Type III. Measure both at head
   and bring the measurement to me; I declare the convention before
   the kernel is written. Afterward D-TWOWAY-PRECISION and the 2e-8
   allowance are removed and all three studies rerun.
7. Forest plot — ADOPT: generated from the ledger with its source
   data; margin factor = limit/discrepancy; refusals as a distinct
   shape; exact equality capped explicitly; NIST by digit margin or a
   separate panel.
8. Registry — ADOPT. Converges with the provenance ruling; becomes the
   source for the coverage table, the paper's Tables 1/S2, and docs.
   Public surface only.
9. Sublime completions — POST-1.0. Item arrived truncated; request the
   remainder.

Standing lists outside the kit: door-round punch list (wizard build
gated on Ian's items 1-21 batch approval, still pending); survey module
Stages 3-6; CI Lane 10 (v47 crash — must land before the frozen release
the paper cites); About menu item; behavioral-constant census; error
sweep to zero before any 1.0 tag.

Open with me: the post-v8 README revisions (send the diff; wording is
mine to approve), and the Type II/III measurement from item 6.
