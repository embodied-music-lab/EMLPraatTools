# Work order — the kit's presentation layer, approved and specified

Fable, 27 August 2026. Ian has approved the two example files verbatim
(`SUMMARY.md` and `exceptions.tsv`, delivered to him from the 98729af run
and included with this order). This order wires them in. Nothing about
the computation changes; `compare.R` gains a generation step.

## What compare.R generates, every run

**1. `results/SUMMARY.md`** — the approved example is the template. The
prose is fixed; the numbers are filled from the live run:

- run date, plugin commit, platform line
- counts: analyses (cells), procedures, comparisons made, agree count
- per-family: row counts and the measured worst case (relative
  difference, and the p magnitude for the Tukey families)
- the refusal count sentence (both-sides number, verified case by case)

Family prose comes from a committed template file
(`results_templates/summary_template.md` or equivalent), with named
placeholders — never string-built in code, so wording changes are edits
to a reviewed file. A family with zero rows this run drops its section;
a NEW declared family with no template section is a hard error, not a
silent omission — the summary must never under-describe the run.

**2. `results/exceptions.tsv`** — generated from the declared rows:

- columns exactly: `analysis`, `quantity`, `plugin_value`, `r_value`,
  `relative_difference`, `reason`
- rows: DECLARED entries where BOTH sides carry a numeric value. Text
  rows (refusal wording) never appear here — they are one sentence in
  the summary.
- `reason` carries the family's plain-English sentence, complete on
  every row, from the same template file. An empty reason is a red
  condition, not a blank cell.
- full-precision values; relative difference in scientific notation.

**3. `results/VERDICT.txt`** stays, with its one label fix already
ordered: the AGREE line states both legs of the rule (relative < 1e-9;
absolute < 1e-12 near zero).

## The folder contract

- `results/` = what a person opens: `SUMMARY.md`, `exceptions.tsv`,
  `VERDICT.txt`, and the two report folders.
- `audit/` = the working record: `reconciliation.tsv`, the two raw
  result tables, machine vocabulary. One-line README at its top:
  "Working record the summary is derived from; column definitions in
  compare.R's header." (This replaces the current `out/`; update the
  three-step run instructions accordingly.)
- `SUMMARY.md`'s closing line points at `audit/`.

## The guard, machine-checked

New validate leg: no file under `results/` (report folders excepted)
contains internal vocabulary. The wordlist is a committed fixture and
starts as: `bucket`, `enforcement`, `DECLARED`, `CONTRACT`, `vmax`,
`vmin`, `maxrel`, `quantities.tsv`, and the `D-` clause-id pattern.
Red demo: seed one clause id into the generated summary. This is the
guard that keeps the working paper from leaking back into the report.

Second leg: generate-then-verify — after generation, the summary's
filled numbers are re-derived from the reconciliation and must match
(agree count, family counts, worst cases). The presentation can never
drift from the measurement.

## Also in this order (already ruled, listed for one commit)

- c0561's clause gets its note; an empty reason anywhere person-facing
  is red from now on.
- Clean-tree attestation recorded for the 98729af run (the paper's
  evidence anchor).

## Acceptance

A cold open of `results/` after a fresh run on Ian's machine: one page
that reads top to bottom, a 34-row exceptions file with a reason on
every row, and nothing that requires knowing our vocabulary. Ian is the
acceptance test — he opens it cold, same as Josh will.

— Fable
