# Work order — the unification layer

Fable, 28 Aug 2026. Supersedes the earlier tier sequencing where they
differ. Sol's accounting is design intent, not measurement; nothing in
the paper's numbers is established until this layer reproduces it.

1. Do not recreate Tier B or Tier C. The runners and scorers stand:
   harness/sweep/tierB_grid.praat + validate/v18_sweep_parity.R;
   harness/sweep/tierC_nist.praat + validate/v19_nist_strd.R; ingestion
   via validate/tools/nist_ingest.R and validate/lre.R.
2. Build one thing: the unification layer in walkthrough/kit/. It
   ingests the three studies' raw outputs (the 624-case walkthrough
   tables, evidence/sweep/results.csv, evidence/nist/results.csv),
   applies each study's declared criterion, and writes one
   grand_ledger.tsv — one row per comparable result, refusals included,
   with study, case_id, procedure, dataset, quantity, both values,
   criterion, discrepancy or digit count, limit, margin, pass/fail,
   reason. Every generated file, count, and figure derives from this
   ledger. The balance invariant runs per study and in total, with the
   expected total computed independently.
3. First measurement task: the Tier B count. The standalone output
   carries 310 quantities; the paper says 626. Reconcile by measurement
   — either the unification legitimately expands the count (per-pair
   rows, dual quantities) or the paper's number is wrong and gets
   corrected. Report which, with the arithmetic.
4. Refusal-set equality and the nine stale expectations land before the
   ledger's first green. The emlResult_MAXROW fix lands before the NIST
   cells run through the public route.
5. Every paper placeholder — the criterion split, the digit ranges, the
   environment line — fills from the ledger of a run at a pushed
   commit. No number travels from Sol's memo or the draft into any
   generated file.

Sequence: refusal fix -> MAXROW fix -> unification layer -> full
three-study run on Ian's machine -> Tier B count verdict -> Fable's
inspection. The two-way direct kernel and the registry follow
separately; the Type II/III measurement comes to Fable before that
kernel is written.

— Fable
