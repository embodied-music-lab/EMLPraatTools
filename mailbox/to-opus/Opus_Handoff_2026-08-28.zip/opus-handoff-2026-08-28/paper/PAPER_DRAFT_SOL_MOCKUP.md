# Validation of the Statistical Procedures Library for the EML Stats & Graphs Praat Plugin

Ian Howell  
Embodied Music Lab  
[ORCID]

## Abstract

This study evaluated the statistical procedures library of EML Stats & Graphs (benchmark paper forthcoming), a Praat plugin for statistical analysis and graphing. Across 17 statistical procedures, 667 validation cases yielded 11,565 comparable results and 21,793 required outputs. Evidence came from three complementary studies: comparison with established R implementations across the library's supported procedure and option combinations, designed cases spanning controlled changes in data structure, and comparison with externally certified reference values. Every comparable result met its predeclared criterion, and every required output was accounted for. The findings support the numerical validity and reporting completeness of the tested procedures under the conditions examined.

**Keywords:** Praat; statistical software validation; numerical accuracy; NIST StRD; phonetics; voice research

## 1. Introduction

Praat was developed within phonetics as software for analyzing, synthesizing, and manipulating speech (Boersma, 2001; Boersma, Weenink, & Shchupak, 2026). Its object system, tables and matrices, scripting language, and drawing system also make it an extensible quantitative environment for work with sound, tabular data, and matrix-structured data across phonetic, speech, and voice research.

Praat includes statistical commands and can produce highly detailed publication-quality drawings, but it does not provide a comprehensive statistics-and-graphing module. Many statistical procedures are absent; available commands are distributed among object-specific menus and may appear only when the required objects have been selected. Praat's drawing system permits extensive control, but rapid production of polished graphs generally requires manual construction or custom scripting.

These capabilities have supported three broad research workflows. First, measurement, a limited set of native statistical analyses, and drawing can be completed within Praat, either interactively or through Praat scripts (Boersma, 2001; Owren, 2008). Second, measurements can be obtained in Praat, exported as tabular data, and imported into a separate programming language or statistical software environment for analysis and visualization; transfer from Praat to R is a typical acoustic-phonetic workflow (Albin, 2014). Third, Praat functions can be invoked from within another programming language. PraatR calls Praat scripts and commands from R (Albin, 2014), whereas Parselmouth exposes Praat functionality within Python (Jadoul, Thompson, & de Boer, 2018).

EML Stats & Graphs (benchmark paper forthcoming) substantially expands the first workflow by adding independently implemented statistical procedures and automated graphing routines within Praat. It uses Praat's object, scripting, numerical, and drawing infrastructure as its host environment, but it does not merely expose native commands through a new interface. The plugin implements procedures, post-hoc analyses, multiplicity adjustments, effect sizes, option handling, reporting logic, and conditions for refusing unsupported analyses that are not available as an equivalent native library, along with graph types and automated layouts not supplied as ready-made Praat commands. Established methods have similarly been implemented within coherent, task-oriented statistical environments (Faul et al., 2007; Love et al., 2019; Vallat, 2018).

Because the statistical procedures contain substantial new analytical logic, their numerical and reporting behavior requires direct validation. Statistical software can be evaluated through comparison with established implementations, designed cases or simulations, and certified reference values (Simon & Lesage, 1989; McCullough, 1998, 1999; McCullough & Wilson, 1999; Pernet et al., 2013; Wilson et al., 2024). This article is the validation companion to the EML Stats & Graphs benchmark paper. It addresses three complementary questions: whether the library agrees with established implementations across its supported combinations of procedures and options, whether that agreement holds across systematically varied dataset structures, and whether its calculations reproduce externally certified values.

## 2. Methods

### 2.1 Validation design and provenance

A **validation case** was one predeclared combination of procedure, dataset, columns, option values, and expected outcome in `matrix.tsv`. A **comparable result** was one named output or expected analysis outcome evaluated against a reference for the same case. Most comparable results were numerical quantities; expected refusals were evaluated as behavior. Outputs produced by only one implementation were checked wherever the predeclared list of required outputs called for them.

The definitions of the validation cases, validation datasets, list of required outputs, pass criteria, and expected refusals were fixed in [FROZEN RELEASE IDENTIFIER] before the reported run. The final validation began from a clean checkout of that release and regenerated both implementations' raw outputs and the complete table of results. No validation case, required result, dataset, criterion, or expected outcome was removed or altered after that run. Any change to the procedures library or validation materials invalidates the reported result for that release and requires a complete rerun.

The Praat and R analysis scripts read the same case definitions and validation datasets but did not share computed values or intermediate statistics. The R script selected calculations from the declared procedure and options rather than from case-specific expected answers, and it called established R functions for the reference calculations. The certified-reference study supplied evidence independent of both implementations.

### 2.2 Overview of the validation studies

The validation was organized around breadth, controlled variation, and external certification. The first study compared the library with established R implementations across the supported combinations of procedures, tests, post-hoc methods, adjustments, and other options that change the results. The second used deliberately constructed datasets to examine selected procedures under controlled changes in group count, sample size, imbalance, ties, and variance. The third compared one-way ANOVA results with values certified by the National Institute of Standards and Technology (NIST). Together, the three studies comprised 667 validation cases and 11,565 comparable results. Their purposes were complementary: the first established coverage across the implemented library, the second extended that evidence beyond the structures represented by the ordinary validation datasets, and the third tested accuracy against an external multiple-precision reference.

### 2.3 Study materials and procedure coverage

**Procedure and option comparison.** This study used 28 version-controlled CSV validation datasets: 16 for the main statistical procedures and 12 for the survey, categorical, and psychometric procedures. The datasets contained 2 to 50 records and 2 to 5 columns and represented two-group and multiple-group designs, paired and repeated-measures data, factorial data, correlation and regression cases, distributional and missing-data conditions, scale-reliability cases, contingency tables, and Wilson-interval cases. `matrix.tsv` listed every lawful combination of dataset, test, post-hoc method, adjustment, variance assumption, group order, and confidence level exposed by the validated procedures. This produced 624 validation cases, including both expected computations and cases expected to refuse analysis when their inputs did not satisfy a procedure's requirements.

**Designed cases.** Sixteen deterministic dataset structures varied the number of groups ($k \in \{2,3,5\}$), observations per group (3 to 200), balance (balanced or 6:1 unbalanced), ties (tie-free through heavily tied), and variance ratio (homoscedastic or 10:1 heteroscedastic). Each dataset was analyzed by one-way ANOVA with Tukey-Kramer comparisons and by Kruskal-Wallis analysis, producing 32 validation cases.

**Certified reference values.** Eleven one-way ANOVA datasets from the NIST Statistical Reference Datasets supplied certified values for degrees of freedom, sums of squares, mean squares, $F$, $R^2$, and residual standard deviation. Each dataset contributed one validation case, for 11 cases in total.

Table 1 lists all 17 procedures, the choices exercised for each, the data conditions represented, and the reference calculation used. “—” means that the procedure offers no post-hoc comparison or multiple-comparison adjustment.

**Table 1. Procedures and validation coverage**

| Procedure | Tests and options exercised | Post-hoc or pairwise comparisons | Adjustments offered | Data conditions represented | Reference calculation | Cases: options/designed/NIST |
|---|---|---|---|---|---|---:|
| Alpha influence | Leave-one-respondent-out influence on Cronbach's alpha | — | — | Ordinary and small-sample scales, including a zero-variance item | `psych::alpha` applied after removing each respondent | 8/0/0 |
| Chi-square independence | With and without Yates's continuity correction | — | — | Ordinary, sparse, and zero-count contingency tables | `stats::chisq.test`; Cramér's V from `effectsize` and `rstatix` | 8/0/0 |
| Cronbach's alpha | 90%, 95%, and 99% confidence intervals | — | — | Multi-item scales, missing data, small samples, and constant items | `psych::alpha`; `psych::alpha.ci` | 22/0/0 |
| One-way ANOVA | With and without post-hoc comparisons; groups kept in table order or sorted alphabetically | Tukey HSD; Tukey-Kramer when group sizes differ | Adjustment is built into Tukey's method | Independent groups; balanced and unbalanced samples; unequal variances; ordinary cases, undefined cases, and NIST datasets designed to expose loss of numerical precision | `stats::aov`; `stats::TukeyHSD`; effect-size functions; NIST-certified values | 40/16/11 |
| Correlation | Pearson, Spearman, or both | — | — | Ordinary paired columns, fewer than three complete pairs, and zero-variance columns | `stats::cor.test` | 35/0/0 |
| Descriptive statistics | One complete descriptive report | — | — | Ordinary, missing, nonnumeric, and constant-column data | Base R; `psych::describe` | 41/0/0 |
| Friedman analysis | With and without follow-up comparisons | Pairwise Wilcoxon signed-rank tests | Benjamini-Hochberg, Bonferroni, and Holm | Repeated measurements with ordinary values, ties, identical values, and missing data | `stats::friedman.test`; paired Wilcoxon and effect-size functions | 22/0/0 |
| Grouped regression | Groups kept in table order or sorted alphabetically | — | — | Separate linear regressions within multiple groups | `stats::lm` | 6/0/0 |
| Kruskal-Wallis analysis | With and without follow-up comparisons; groups kept in table order or sorted alphabetically | Dunn's test | Benjamini-Hochberg, Bonferroni, and Holm | Two, three, and five groups; balanced and 6:1 unbalanced samples; tie-free through heavily tied data | `stats::kruskal.test`; `rstatix::dunn_test`; effect-size functions | 80/16/0 |
| Normality analysis | Shapiro-Wilk test with skewness and kurtosis | — | — | Ordinary, small, missing, and constant samples | `stats::shapiro.test`; `psych::describe` | 41/0/0 |
| Paired analysis | Paired *t* test, Wilcoxon signed-rank test, or both | — | — | Complete and incomplete pairs, zero-variance differences, and exact and approximate rank-test cases | `stats::t.test`; `stats::wilcox.test`; effect-size functions | 25/0/0 |
| Standalone pairwise analysis | Welch *t*, Student *t*, Wilcoxon rank-sum, or Scheffé; groups kept in table order or sorted alphabetically | All pairwise group comparisons | Benjamini-Hochberg, Bonferroni, or Holm for *t* and Wilcoxon comparisons; Scheffé controls multiplicity as part of the method | Multiple independent groups with equal and unequal variances | Pairwise *t* and Wilcoxon functions; `stats::p.adjust`; direct Scheffé calculation | 200/0/0 |
| Regression | Overall linear regression | — | — | Ordinary, missing, and insufficient-sample cases | `stats::lm`; `stats::cor` | 10/0/0 |
| Repeated-measures analysis | With and without follow-up comparisons | Pairwise paired *t* tests | Benjamini-Hochberg, Bonferroni, and Holm | Two or more repeated conditions, missing observations, and zero residual variance | `afex::aov_ez`; paired *t* and effect-size functions | 22/0/0 |
| Two-group analysis | Student *t*, Welch *t*, Wilcoxon rank-sum, or both parametric and nonparametric tests; groups kept in table order or sorted alphabetically | — | — | Exactly two groups, unequal variances, missing values, and inputs containing more than two groups | `stats::t.test`; `stats::wilcox.test`; effect-size functions | 34/0/0 |
| Two-way ANOVA | Two-factor model with interaction | — | — | Complete factorial data and an input that cannot support the model | `car::Anova`; effect-size functions | 3/0/0 |
| Wilson interval | 90%, 95%, and 99% confidence intervals | — | — | Boundary proportions and published comparison cases | `stats::prop.test`; published-case identity checks | 27/0/0 |

*Note.* The three case counts refer to the procedure-and-option comparison, the designed cases, and the NIST datasets. They sum to 624, 32, and 11 respectively, for 667 validation cases.

The studies were run on 29 August 2026 using Praat 6.6.30 and R 4.5.2 on x86_64-apple-darwin20. Exact package versions are recorded in [ARCHIVED SESSIONINFO RECORD]. R references used base R and the `rstatix`, `effectsize`, `car`, `afex`, and `psych` packages. Scheffé comparisons were calculated from the published definition using R's F-distribution functions (Scheffé, 1953). The one- and two-way ANOVA calculations were implemented directly in the procedures library and compared with `stats::aov`, `car::Anova`, and the designated effect-size references. A separate file, `quantities.tsv`, specified which outputs each procedure had to produce in each implementation. Supplementary Table S2 records the statistical definition and exact reference functions used for every procedure.

### 2.4 Pass criteria and complete accounting

For the R comparisons and designed cases, relative difference was calculated as

\[
d_{rel}=\frac{|x_P-x_R|}{\max(|x_P|,|x_R|)}.
\]

The standard rule required $d_{rel}<10^{-9}$. When both magnitudes were below $10^{-12}$, absolute difference below $10^{-12}$ was required instead. Extreme-tail Tukey probabilities below $10^{-9}$ were evaluated under a relative-difference limit of $5\times10^{-3}$ because the corresponding studentized-range statistics met the standard rule while the probability calculations used different far-tail quadrature. The two alpha-influence results involving a constant item were checked against the specified covariance calculation. A refusal passed only when the cases refused by Praat, the cases refused by R, and the predeclared list of expected refusals were identical; explanatory wording did not have to match. An output passed the reporting check when it appeared in every implementation from which `quantities.tsv` required it.

For the NIST comparison, the 22 between- and within-group degrees of freedom were required to match exactly. For the remaining 76 certified quantities, correct significant digits were estimated as

\[
LRE=-\log_{10}\left(\frac{|x-c|}{|c|}\right),
\]

where \(x\) is the computed value and \(c\) is the NIST-certified value. This expresses accuracy as an estimated number of correct digits. The NIST rule was specified before the final run: each EML/Praat result passed when it retained no more than one fewer correct digit than base R on the same dataset and quantity.

## 3. Results

All three validation studies passed. The procedure and option comparison passed 10,841 of 10,841 comparable results, the designed cases passed 626 of 626, and the NIST comparison passed 98 of 98. Across the complete suite, all 11,565 comparable results met their declared criteria and all 21,793 required outputs were accounted for. Table 2 provides the more detailed accounting by the criterion applied to each result.

**Table 2. Complete validation accounting**

| Pass criterion | Results evaluated | Passed | Failed | What was checked | Observed result |
|---|---:|---:|---:|---|---|
| Standard comparison with R | 11,428 | 11,428 | 0 | Corresponding Praat and R values agreed within $10^{-9}$ relative error, or $10^{-12}$ absolute error when both values were near zero | Largest observed discrepancy: [MAXIMUM STANDARD DISCREPANCY]; smallest factor inside the acceptance limit: [SMALLEST FACTOR INSIDE ACCEPTANCE LIMIT] |
| Extreme-tail Tukey probabilities | 17 | 17 | 0 | The Tukey $q$ statistic met the standard comparison, and the resulting probability remained within its separate tail bound | Maximum relative probability difference $1.27\times10^{-3}$; permitted maximum $5\times10^{-3}$ |
| Alpha influence with a constant item | 2 | 2 | 0 | The plugin retained the stated item set and reproduced the covariance calculation | Both values matched the stated calculation |
| Refusal of unsupported analyses | 20 | 20 | 0 | The cases refused by Praat and R were each required to equal the predeclared list of expected refusals | The same 20 expected cases were refused on both sides, with no missing or additional refusals |
| NIST degrees of freedom | 22 | 22 | 0 | Between- and within-group degrees of freedom equaled the NIST-certified integers | All 22 matched exactly |
| Other NIST ANOVA quantities | 76 | 76 | 0 | Sums of squares, mean squares, $F$, $R^2$, and residual standard deviation were compared with NIST-certified values | EML/Praat minus R correct-digit range: [MINIMUM TO MAXIMUM DIGITS] |
| **All comparable results** | **11,565** | **11,565** | **0** | **All 667 validation cases** | **Every result passed its stated criterion** |
| Required outputs present | 21,793 | 21,793 | 0 | Every output specified in `quantities.tsv` appeared in the required implementation or was not required because the case was expected to refuse analysis | All required outputs were accounted for |

The categories in Table 2 identify the rule applied to each result; they are not separate levels of validity. The check that every required output was present also passed: all 21,793 outputs specified in `quantities.tsv` were present or correctly not required because an expected refusal occurred.

Supplementary Table S1, stored as `grand_ledger.tsv`, contains one row for every comparable result, including the procedure, validation case, dataset, quantity, EML/Praat value, reference value, pass criterion, observed discrepancy or correct-digit count, factor inside the acceptance limit where applicable, and pass/fail result.

[FIGURE 1 — REGENERATED FROM THE FINAL `grand_ledger.tsv`]

**Figure 1. Margins above the acceptance threshold across all numerical results.** For each numerical result, the plotted value is the applicable acceptance limit divided by the observed discrepancy; $10^0$ is therefore the pass boundary, and $10^k$ indicates that the discrepancy was $k$ orders of magnitude inside the limit. Each procedure row shows the complete range of its numerical results, together with the interquartile range and median. Values at or beyond $10^6$ are displayed at $\geq10^6$. Cases correctly refused by both implementations are shown separately as diamonds above the pass boundary because refusal is categorical and has no numerical margin. The figure summarizes a range of results per procedure, not a single precision estimate for that procedure.

## 4. Discussion

Across the complete validation suite, all 11,565 comparable results met their declared criteria and all 21,793 required outputs were accounted for. This is the central result: within the examined scope, the library produced accurate values, complete reports, and refused analysis in every predeclared case in which refusal was expected.

The three studies provide complementary evidence for that conclusion. Comparison with R establishes breadth across 17 procedures and the option combinations represented by the validation cases. The designed cases extend the comparison across controlled changes in group count, sample size, imbalance, ties, and variance ratio. The NIST datasets provide an external multiple-precision reference for balanced one-way ANOVA.

Agreement with R across the tested procedures and option combinations directly validates the implementation against established reference functions, while the certified values reduce dependence on agreement between two software implementations. Exact comparison of the expected and observed refusals, together with the check that every required output was present, establishes that passing also requires appropriate behavior and complete reporting, not numerical agreement alone. Taken together, the three studies support the numerical validity and reporting completeness of the tested procedures under the declared conditions. The claim does not extend to untested dataset structures, future software versions, or procedures outside the library; the validation should be regenerated for every archived release.

## Data and code availability

The definitions of the validation cases, validation datasets, Praat and R analysis scripts, raw result tables, complete table of results (`grand_ledger.tsv`), script used to generate the designed datasets, NIST comparison scripts, and archived `sessionInfo()` record are available in the [EML Stats & Graphs repository](https://github.com/embodied-music-lab/EMLPraatTools). The frozen release is archived at [ARCHIVED RELEASE DOI] and corresponds to commit [REPOSITORY COMMIT]. NIST StRD datasets and certified values are available from <https://www.itl.nist.gov/div898/strd/>.

## Funding

[FUNDING STATEMENT]

## Competing interests

Ian Howell is the developer of EML Stats & Graphs (benchmark paper forthcoming), the creator of EML PraatGen (benchmark paper forthcoming), and the founder of Embodied Music Lab. The software is distributed under the GPL-3.0-or-later license. [ADDITIONAL COMPETING INTERESTS]

## Ethics statement

The validation used constructed, demonstration, survey, and publicly available statistical reference data. It involved no human participants and no identifiable private data.

## Development disclosure

EML PraatGen (benchmark paper forthcoming) and language models contributed to development of the software and validation materials. Language models have also been used incidentally in developing deterministic research code (Burke et al., 2024; Cregg et al., 2024; Anglen et al., 2025; Cheung & Guzman, 2026). Claude performed substantial code generation and revision, and ChatGPT Sol was used for adversarial review. Ian Howell specified the project, selected and adjudicated statistical definitions, reviewed the outputs, and approved the software, analyses, and manuscript. Language-model output was not validation evidence; acceptance depended on comparisons with R, direct calculations, and NIST-certified values.

## References

Albin, A. L. (2014). PraatR: An architecture for controlling the phonetics software “Praat” with the R programming language. *The Journal of the Acoustical Society of America, 135*(4 Suppl.), 2198-2199. <https://doi.org/10.1121/1.4877175>

Anglen, T., Kaplow, I. M., Choi, B., Dewars, E., Perelli, R. M., Hagy, K. T., Tran, D., Ramaker, M. E., Shah, S. H., Jung, I., Landstrom, A. P., Karra, R., Diao, Y., & Gersbach, C. A. (2025). A gene regulatory element modulates myosin expression and controls cardiomyocyte response to stress. *Genome Research, 35*(11), 2418-2432. <https://doi.org/10.1101/gr.280825.125>

Ben-Shachar, M. S., Lüdecke, D., & Makowski, D. (2020). `effectsize`: Estimation of effect size indices and standardized parameters. *Journal of Open Source Software, 5*(56), 2815. <https://doi.org/10.21105/joss.02815>

Boersma, P. (2001). Praat, a system for doing phonetics by computer. *Glot International, 5*(9/10), 341-345.

Boersma, P., Weenink, D., & Shchupak, A. (2026). *Praat: Doing phonetics by computer* [Computer program; version 6.6.30 used for validation]. <https://praat.org>

Burke, N., Müller, G., Saggiomo, V., Hassett, A. R., Mutterer, J., Ó Súilleabháin, P., Zakharov, D., Healy, D., Reynaud, E. G., & Pickering, M. (2024). EnderScope: A low-cost 3D printer-based scanning microscope for microplastic detection. *Philosophical Transactions of the Royal Society A: Mathematical, Physical and Engineering Sciences, 382*(2274), 20230214. <https://doi.org/10.1098/rsta.2023.0214>

Cheung, Y. Y. J., & Guzman, L. M. (2026). MetaCommunityMetrics.jl: A Julia package for spatiotemporal metacommunity analysis. *Journal of Open Source Software, 11*(123), 10167. <https://doi.org/10.21105/joss.10167>

Cregg, J. M., Sidhu, S. K., Leiras, R., & Kiehn, O. (2024). Basal ganglia-spinal cord pathway that commands locomotor gait asymmetries in mice. *Nature Neuroscience, 27*, 716-727. <https://doi.org/10.1038/s41593-024-01569-8>

Faul, F., Erdfelder, E., Lang, A.-G., & Buchner, A. (2007). G*Power 3: A flexible statistical power analysis program for the social, behavioral, and biomedical sciences. *Behavior Research Methods, 39*(2), 175-191. <https://doi.org/10.3758/BF03193146>

Fox, J., & Weisberg, S. (2019). *An R companion to applied regression* (3rd ed.). Sage.

Jadoul, Y., Thompson, B., & de Boer, B. (2018). Introducing Parselmouth: A Python interface to Praat. *Journal of Phonetics, 71*, 1-15. <https://doi.org/10.1016/j.wocn.2018.07.001>

Kassambara, A. (2026). *rstatix: Pipe-friendly framework for basic statistical tests* [R package]. <https://CRAN.R-project.org/package=rstatix>

Love, J., Selker, R., Marsman, M., Jamil, T., Dropmann, D., Verhagen, J., Ly, A., Gronau, Q. F., Šmíra, M., Epskamp, S., Matzke, D., Wild, A., Knight, P., Rouder, J. N., Morey, R. D., & Wagenmakers, E.-J. (2019). JASP: Graphical statistical software for common statistical designs. *Journal of Statistical Software, 88*(2), 1-17. <https://doi.org/10.18637/jss.v088.i02>

McCullough, B. D. (1998). Assessing the reliability of statistical software: Part I. *The American Statistician, 52*(4), 358-366. <https://doi.org/10.1080/00031305.1998.10480597>

McCullough, B. D. (1999). Assessing the reliability of statistical software: Part II. *The American Statistician, 53*(2), 149-159. <https://doi.org/10.1080/00031305.1999.10474450>

McCullough, B. D., & Wilson, B. (1999). On the accuracy of statistical procedures in Microsoft Excel 97. *Computational Statistics & Data Analysis, 31*(1), 27-37. <https://doi.org/10.1016/S0167-9473(99)00004-3>

National Institute of Standards and Technology. (n.d.-a). *How to use Statistical Reference Datasets*. <https://www.itl.nist.gov/div898/strd/general/howto.html>

National Institute of Standards and Technology. (n.d.-b). *StRD analysis of variance datasets: Background information*. <https://www.itl.nist.gov/div898/strd/anova/background.html>

Owren, M. J. (2008). GSU Praat Tools: Scripts for modifying and analyzing sounds using Praat acoustics software. *Behavior Research Methods, 40*(3), 822-829. <https://doi.org/10.3758/BRM.40.3.822>

Pernet, C. R., Wilcox, R., & Rousselet, G. A. (2013). Robust correlation analyses: False positive and power validation using a new open source Matlab toolbox. *Frontiers in Psychology, 3*, 606. <https://doi.org/10.3389/fpsyg.2012.00606>

R Core Team. (2026). *R: A language and environment for statistical computing*. R Foundation for Statistical Computing. <https://www.R-project.org/>

Revelle, W. (2025). *psych: Procedures for psychological, psychometric, and personality research* [R package]. Northwestern University. <https://CRAN.R-project.org/package=psych>

Scheffé, H. (1953). A method for judging all contrasts in the analysis of variance. *Biometrika, 40*(1-2), 87-110. <https://doi.org/10.1093/biomet/40.1-2.87>

Simon, S. D., & Lesage, J. P. (1989). Assessing the accuracy of ANOVA calculations in statistical software. *Computational Statistics & Data Analysis, 8*(3), 325-332. <https://doi.org/10.1016/0167-9473(89)90048-0>

Singmann, H., Bolker, B., Westfall, J., Aust, F., & Ben-Shachar, M. S. (2024). *afex: Analysis of factorial experiments* [R package]. <https://CRAN.R-project.org/package=afex>

Vallat, R. (2018). Pingouin: Statistics in Python. *Journal of Open Source Software, 3*(31), 1026. <https://doi.org/10.21105/joss.01026>

Wilson, K. J., Roldán-Nofuentes, J. A., & Henrion, M. Y. R. (2024). testCompareR: An R package to compare two binary diagnostic tests using paired data. *Wellcome Open Research, 9*, 351. <https://doi.org/10.12688/wellcomeopenres.22411.4>

## Supplementary Table S2. Procedure definitions and reference implementations

Exact R and package versions are preserved in [ARCHIVED SESSIONINFO RECORD]. Function arguments shown below are the choices that affect numerical results; complete calls and reported outputs are preserved in `run_analyses.R` and `quantities.tsv`.

| Procedure | Statistical construction implemented in EML/Praat | R reference implementation |
|---|---|---|
| Alpha influence | Cronbach's alpha for the complete respondent-by-item matrix and again after removing each respondent; influence is the change from the complete-sample alpha | `psych::alpha(check.keys = FALSE)` on the complete matrix and on each leave-one-respondent-out matrix |
| Chi-square independence | Pearson chi-square test of independence, optionally with Yates's continuity correction; uncorrected Cramér's V | `stats::chisq.test(correct = ...)`; `rstatix::cramer_v(correct = FALSE)`; `effectsize::cramers_v(adjust = FALSE)` |
| Cronbach's alpha | Raw Cronbach's alpha, alpha if each item is deleted, and Feldt confidence interval at the requested confidence level | `psych::alpha(check.keys = FALSE)`; `psych::alpha.ci` |
| One-way ANOVA | Equal-variance one-factor ANOVA; eta squared; Tukey HSD, using Tukey-Kramer standard errors for unequal group sizes | `stats::aov`; `stats::TukeyHSD`; `rstatix::eta_squared`; `effectsize::eta_squared(partial = FALSE)` |
| Correlation | Pearson product-moment correlation and Spearman rank correlation, including the method-specific test statistic and probability | `stats::cor.test(method = "pearson")`; `stats::cor.test(method = "spearman")` |
| Descriptive statistics | Count, mean, sample variance and standard deviation, standard error, median, range, R-7 quartiles and IQR, type-2 skewness and excess kurtosis, and a *t*-based interval for the mean | `psych::describe`; `stats::var`; `stats::quantile(type = 7)`; `stats::IQR`; `psych::skew(type = 2)`; `psych::kurtosi(type = 2)`; `stats::t.test` |
| Friedman analysis | Friedman rank test for complete repeated measurements; Kendall's W; paired Wilcoxon follow-ups with the selected adjustment | `stats::friedman.test`; `rstatix::friedman_effsize`; `effectsize::kendalls_w`; `rstatix::wilcox_test(paired = TRUE)`; `stats::p.adjust` |
| Grouped regression | Ordinary least-squares simple regression for the complete sample and separately within each declared group | `stats::lm` on the complete data and within each group |
| Kruskal-Wallis analysis | Kruskal-Wallis rank-sum test; rank eta squared and epsilon squared; Dunn follow-ups with the selected adjustment | `stats::kruskal.test`; `rstatix::kruskal_effsize`; `effectsize::rank_eta_squared`; `effectsize::rank_epsilon_squared`; `rstatix::dunn_test`; `stats::p.adjust` |
| Normality analysis | Shapiro-Wilk test accompanied by count, mean, standard deviation, median, type-2 skewness, and excess kurtosis | `stats::shapiro.test`; `psych::describe`; `psych::skew(type = 2)`; `psych::kurtosi(type = 2)` |
| Paired analysis | Paired Student *t* test and Cohen's $d_z$; Wilcoxon signed-rank test and matched-pairs rank-biserial correlation | `stats::t.test(paired = TRUE)`; `effectsize::cohens_d(paired = TRUE)`; `stats::wilcox.test(paired = TRUE)`; `effectsize::rank_biserial(paired = TRUE)` |
| Standalone pairwise analysis | All group pairs by Welch *t*, pooled Student *t*, Wilcoxon rank-sum, or Scheffé; Benjamini-Hochberg, Bonferroni, or Holm adjustment where applicable | `rstatix::t_test`; `stats::t.test`; `rstatix::wilcox_test`; `stats::wilcox.test`; `stats::p.adjust`; Scheffé statistic and interval from `stats::pf` and `stats::qf` |
| Regression | Ordinary least-squares simple regression with coefficient tests, model *F*, $R^2$, adjusted $R^2$, residual standard error, and signed correlation | `stats::lm`; `stats::cor` |
| Repeated-measures analysis | One-factor repeated-measures ANOVA with Greenhouse-Geisser correction and paired *t* follow-ups using the selected adjustment | `afex::aov_ez`; `effectsize::eta_squared(partial = TRUE)`; `rstatix::t_test(paired = TRUE)`; `stats::p.adjust` |
| Two-group analysis | Pooled Student or Welch independent-samples *t* test; Wilcoxon rank-sum test; Cohen's *d*, Hedges' *g*, and rank-biserial correlation | `stats::t.test(var.equal = ...)`; `stats::wilcox.test`; `effectsize::cohens_d`; `effectsize::hedges_g`; `effectsize::rank_biserial` |
| Two-way ANOVA | Two-factor fixed-effects model with interaction and Type II sums of squares; termwise partial eta squared | `stats::lm(response ~ factor1 * factor2)`; `car::Anova(type = 2)`; `effectsize::eta_squared(partial = TRUE)` |
| Wilson interval | Wilson score interval for a binomial proportion without continuity correction | `stats::prop.test(correct = FALSE)` and published-case identity checks |
