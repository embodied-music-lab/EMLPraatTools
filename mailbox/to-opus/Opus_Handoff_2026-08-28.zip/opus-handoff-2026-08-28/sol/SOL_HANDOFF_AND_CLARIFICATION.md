# Sol's coding handoff (verbatim, via Ian) and Sol's clarification

Two documents from ChatGPT Sol, 28 August 2026, relayed by Ian. Item 9 of
the handoff arrived truncated. Fable's dispositions are in
`RULINGS_SOL_ITEMS_2026-08-28.md`; where they conflict, Fable's rulings
govern.

## Document 1 — the handoff

1. **Make the validation kit the single source of evidence.** One
   authoritative `grand_ledger.tsv`, one row per comparable result
   including matched refusals, with: validation study, case id,
   procedure, dataset, quantity, Praat state and value, reference state
   and value, criterion, observed discrepancy or correct-digit count,
   acceptance limit, margin, pass/fail, reason. All summaries, tables,
   and figures generate from it. Use "validation case" (case_id) in
   human-facing output, "cell_id" internal only. Use "refusal," not
   "rejection."
2. **Preserve three distinct validation studies** (R comparison 624
   cases / 10,841 results; designed structures 32 cases / 626 results;
   NIST 11 datasets / 98 results — totals 667 / 11,565 / 21,793).
   Reconciliation verifies totals independently. Claimed criterion
   accounting: 11,428 standard + 17 Tukey-tail + 2 alpha-influence +
   20 matched refusals + 22 NIST df + 76 NIST digit = 11,565.
3. **Exact refusal-set equality.** Old comparator checked declared
   refusals occurred, not that actual refusals were declared (11
   declared vs 20 actual). Update nine stale expectation annotations;
   require observed Praat = observed R = expected; fail on missing or
   additional; report 20/20.
4. **NIST validation:** compare Praat AND base R to certified values;
   22 df exact; 76 quantities by LRE correct digits; Praat passes at no
   more than one digit below base R; keep 10 residual-SD assertions
   (98 total). Ledger exposes digits for both sides, minimum required,
   margin, status. No general relative-error threshold on NIST; no
   forcing NIST into a common plot; archive complete output.
5. **Remove the large-output failure:** `eml-result-writer.praat`
   `emlResult_MAXROW` = 4,000 aborts SmLs03/06/09 export at 18,009
   rows. Raise/stream/avoid; public NIST route completes for every
   dataset; regression test.
6. **Finish the ANOVA change.** One-way: confirm direct kernel used
   throughout the public route, full precision to ledger, rounding only
   at formatting. Two-way: remove the `Report two-way anova` parser;
   implement directly (both mains + interaction; SS convention per the
   R oracle — currently claimed car::Anova type = 2; SS/df/MS/F/p,
   residual and total, design info, eta and partial eta squared;
   deliberate unbalanced/missing-cell handling; named refusals;
   existing report/export interface preserved). Residual SS within
   cells: SS_E = sum(y_ijk − ybar_ij)² = sum y² − sum(T_ij²/n_ij);
   SS_T = sum y² − T…²/N. Afterward: remove D-TWOWAY-PRECISION and the
   2e-8 allowance; update quantities.tsv, comments, docs, provenance;
   rerun all three studies.
7. **Forest plot from the final ledger.** Factor inside limit =
   acceptance limit / observed discrepancy; reference line at 10^0;
   per-procedure ranges; log labels; exact equality flagged or capped;
   matched refusals as a distinct shape with no fabricated discrepancy;
   clear counts; NIST by digit margin or a separate aligned panel.
   Figure and its source data generate from grand_ledger.tsv.
8. **Machine-readable public-procedure registry** for the 17 procedures
   (canonical name, exact signature, argument names/types, accepted
   test values, post-hoc options, adjustments, confidence/correction
   options, defaults, global-state dependencies, input shape, output
   schema, expected refusal conditions, required include file, minimal
   scripting example). The 17-row coverage table generates from it.
   Registry covers the public surface, not internal helpers.
9. **Use the registry for the Sublime Text integration.** Generate
   Sublime Text completions, [TRUNCATED — remainder not received].

## Document 2 — Sol's clarification on Tier B/C machinery

Sol wrote no new Tier B/C scripts. Existing infrastructure:
`harness/sweep/tierB_grid.praat` + `validate/v18_sweep_parity.R` +
`evidence/sweep/`; `harness/sweep/tierC_nist.praat` +
`validate/v19_nist_strd.R` + `evidence/nist/`; ingestion
`validate/tools/nist_ingest.R` and `validate/lre.R`. tierB_grid
deterministically generates 16 datasets, runs ANOVA/Tukey and KW, writes
manifest.csv + 16 data files + results.csv; v18 recalculates with aov,
TukeyHSD, kruskal.test and scores. tierC runs emlOneWayAnova on every
ingested NIST dataset; v19 computes base-R results and compares both to
certified values by correct digits.

What does not exist: the merging layer producing grand_ledger.tsv and
the 11,565-result reconciliation. Sol combined counts CONCEPTUALLY.
Sol's instruction, adopted: do not recreate Tier B/C; incorporate their
raw results; build the unification layer; do not treat the 626 Tier B
count as established until the unification code reproduces it — the
standalone Tier B output contains 310 reported quantities, and v18 does
not produce a 626-row ledger. Reconstruct how 626 arose or correct the
paper's count.
