Survey builder seed — give both documents to a clean Opus 5 session.
Read SURVEY_BUILDER_BRIEF first; it references the plan.
Built: 2026-08-26T00:06Z. Verify: sha256sum -c SHA256SUMS.txt
